// test/RoomChain.test.js
const { expect }  = require("chai");
const { ethers }  = require("hardhat");
const { time }    = require("@nomicfoundation/hardhat-network-helpers");

describe("RoomChain", function () {
  let roomChain;
  let owner, host, host2, guest, guest2, attacker;

  const PRICE_PER_HOUR = ethers.parseEther("0.01");
  const CAPACITY       = 10n;

  let now, checkIn, checkOut;

  beforeEach(async () => {
    [owner, host, host2, guest, guest2, attacker] = await ethers.getSigners();

    const RC = await ethers.getContractFactory("RoomChain");
    roomChain = await RC.deploy();
    await roomChain.waitForDeployment();

    now      = BigInt(await time.latest());
    checkIn  = now + 3600n;          // 1 h from now
    checkOut = now + 7200n;          // 2 h from now → 2 h stay
  });

  // ─── Helpers ────────────────────────────────────────────────────────────────

  async function listDefaultRoom(signer = host) {
    const tx = await roomChain.connect(signer).listRoom(
      "Test Room", "Test Location", "A test room", "https://img.test",
      PRICE_PER_HOUR, CAPACITY
    );
    const receipt = await tx.wait();
    const log     = receipt.logs.find(l => { try { roomChain.interface.parseLog(l); return true; } catch { return false; } });
    return roomChain.interface.parseLog(log).args.roomId;
  }

  async function bookDefault(roomId, signer = guest) {
    const cost = PRICE_PER_HOUR * 2n; // 2 hours
    const tx   = await roomChain.connect(signer).bookRoom(roomId, checkIn, checkOut, { value: cost });
    const receipt = await tx.wait();
    const log     = receipt.logs.find(l => {
      try { const p = roomChain.interface.parseLog(l); return p.name === "BookingCreated"; } catch { return false; }
    });
    return roomChain.interface.parseLog(log).args.bookingId;
  }

  // ─── Deployment ─────────────────────────────────────────────────────────────

  describe("Deployment", () => {
    it("sets deployer as owner", async () => {
      expect(await roomChain.owner()).to.equal(owner.address);
    });
    it("sets platform fee to 300 bps (3%)", async () => {
      expect(await roomChain.platformFeeBps()).to.equal(300n);
    });
  });

  // ─── Room listing ────────────────────────────────────────────────────────────

  describe("listRoom", () => {
    it("lists a room and emits RoomListed", async () => {
      await expect(
        roomChain.connect(host).listRoom(
          "My Room", "London", "Nice room", "ipfs://img",
          PRICE_PER_HOUR, CAPACITY
        )
      ).to.emit(roomChain, "RoomListed")
        .withArgs(1n, host.address, "My Room", PRICE_PER_HOUR, CAPACITY);
    });

    it("increments totalRooms", async () => {
      await listDefaultRoom();
      await listDefaultRoom(host2);
      expect(await roomChain.totalRooms()).to.equal(2n);
    });

    it("reverts on empty name", async () => {
      await expect(
        roomChain.connect(host).listRoom("", "L", "D", "U", PRICE_PER_HOUR, CAPACITY)
      ).to.be.revertedWith("RC: empty name");
    });

    it("reverts on zero price", async () => {
      await expect(
        roomChain.connect(host).listRoom("R", "L", "D", "U", 0, CAPACITY)
      ).to.be.revertedWith("RC: zero price");
    });

    it("reverts on zero capacity", async () => {
      await expect(
        roomChain.connect(host).listRoom("R", "L", "D", "U", PRICE_PER_HOUR, 0)
      ).to.be.revertedWith("RC: zero capacity");
    });
  });

  // ─── Room activation ─────────────────────────────────────────────────────────

  describe("setRoomActive", () => {
    it("host can deactivate and reactivate", async () => {
      const id = await listDefaultRoom();
      await roomChain.connect(host).setRoomActive(id, false);
      expect((await roomChain.rooms(id)).active).to.be.false;
      await roomChain.connect(host).setRoomActive(id, true);
      expect((await roomChain.rooms(id)).active).to.be.true;
    });

    it("non-host cannot deactivate", async () => {
      const id = await listDefaultRoom();
      await expect(
        roomChain.connect(attacker).setRoomActive(id, false)
      ).to.be.revertedWith("RC: not host");
    });
  });

  // ─── Booking ─────────────────────────────────────────────────────────────────

  describe("bookRoom", () => {
    let roomId;
    beforeEach(async () => { roomId = await listDefaultRoom(); });

    it("creates booking and emits BookingCreated", async () => {
      const cost = PRICE_PER_HOUR * 2n;
      await expect(
        roomChain.connect(guest).bookRoom(roomId, checkIn, checkOut, { value: cost })
      ).to.emit(roomChain, "BookingCreated")
        .withArgs(1n, roomId, guest.address, checkIn, checkOut, cost);
    });

    it("reverts with wrong ETH amount", async () => {
      await expect(
        roomChain.connect(guest).bookRoom(roomId, checkIn, checkOut, { value: ethers.parseEther("1") })
      ).to.be.revertedWith("RC: wrong ETH amount");
    });

    it("reverts when check-in is in the past", async () => {
      const past = now - 100n;
      await expect(
        roomChain.connect(guest).bookRoom(roomId, past, past + 3600n, { value: PRICE_PER_HOUR })
      ).to.be.revertedWith("RC: check-in in past");
    });

    it("reverts when checkout before check-in", async () => {
      await expect(
        roomChain.connect(guest).bookRoom(roomId, checkIn, checkIn - 1n, { value: PRICE_PER_HOUR })
      ).to.be.revertedWith("RC: invalid checkout");
    });

    it("reverts when stay is less than 1 hour", async () => {
      await expect(
        roomChain.connect(guest).bookRoom(roomId, checkIn, checkIn + 1800n, { value: PRICE_PER_HOUR / 2n })
      ).to.be.revertedWith("RC: min 1 hour");
    });

    it("reverts on overlapping slot", async () => {
      await bookDefault(roomId, guest);
      await expect(
        roomChain.connect(guest2).bookRoom(roomId, checkIn, checkOut, { value: PRICE_PER_HOUR * 2n })
      ).to.be.revertedWith("RC: slot unavailable");
    });

    it("allows non-overlapping back-to-back bookings", async () => {
      await bookDefault(roomId, guest);
      const cost2 = PRICE_PER_HOUR * 2n;
      await expect(
        roomChain.connect(guest2).bookRoom(roomId, checkOut, checkOut + 7200n, { value: cost2 })
      ).to.emit(roomChain, "BookingCreated");
    });

    it("credits host balance correctly", async () => {
      const cost    = PRICE_PER_HOUR * 2n;
      await bookDefault(roomId, guest);
      const expected = cost - (cost * 300n) / 10_000n;
      expect(await roomChain.hostBalance(host.address)).to.equal(expected);
    });

    it("reverts booking inactive room", async () => {
      await roomChain.connect(host).setRoomActive(roomId, false);
      await expect(
        roomChain.connect(guest).bookRoom(roomId, checkIn, checkOut, { value: PRICE_PER_HOUR * 2n })
      ).to.be.revertedWith("RC: room not active");
    });
  });

  // ─── Cancellation ────────────────────────────────────────────────────────────

  describe("cancelBooking", () => {
    let roomId, bookingId;
    beforeEach(async () => {
      roomId    = await listDefaultRoom();
      bookingId = await bookDefault(roomId);
    });

    it("full refund when >48h before check-in", async () => {
      const before = await ethers.provider.getBalance(guest.address);
      const tx     = await roomChain.connect(guest).cancelBooking(bookingId);
      const rcpt   = await tx.wait();
      const gas    = rcpt.gasUsed * rcpt.gasPrice;
      const after  = await ethers.provider.getBalance(guest.address);
      expect(after + gas - before).to.equal(PRICE_PER_HOUR * 2n);
    });

    it("50% refund when 24–48h before check-in", async () => {
      // Fast-forward so only 36 h remains
      await time.increaseTo(checkIn - 36n * 3600n);
      const cost   = PRICE_PER_HOUR * 2n;
      const before = await ethers.provider.getBalance(guest.address);
      const tx     = await roomChain.connect(guest).cancelBooking(bookingId);
      const rcpt   = await tx.wait();
      const gas    = rcpt.gasUsed * rcpt.gasPrice;
      const after  = await ethers.provider.getBalance(guest.address);
      expect(after + gas - before).to.equal(cost / 2n);
    });

    it("no refund within 24h of check-in", async () => {
      await time.increaseTo(checkIn - 3600n);
      const before = await ethers.provider.getBalance(guest.address);
      const tx     = await roomChain.connect(guest).cancelBooking(bookingId);
      const rcpt   = await tx.wait();
      const gas    = rcpt.gasUsed * rcpt.gasPrice;
      const after  = await ethers.provider.getBalance(guest.address);
      expect(after + gas - before).to.equal(0n);
    });

    it("reverts double cancel", async () => {
      await roomChain.connect(guest).cancelBooking(bookingId);
      await expect(
        roomChain.connect(guest).cancelBooking(bookingId)
      ).to.be.revertedWith("RC: already cancelled");
    });

    it("non-guest cannot cancel", async () => {
      await expect(
        roomChain.connect(attacker).cancelBooking(bookingId)
      ).to.be.revertedWith("RC: not guest");
    });
  });

  // ─── Completion ──────────────────────────────────────────────────────────────

  describe("completeBooking", () => {
    it("host marks booking complete after checkout", async () => {
      const roomId    = await listDefaultRoom();
      const bookingId = await bookDefault(roomId);
      await time.increaseTo(checkOut + 1n);
      await expect(
        roomChain.connect(host).completeBooking(bookingId)
      ).to.emit(roomChain, "BookingCompleted");
    });

    it("reverts before checkout time", async () => {
      const roomId    = await listDefaultRoom();
      const bookingId = await bookDefault(roomId);
      await expect(
        roomChain.connect(host).completeBooking(bookingId)
      ).to.be.revertedWith("RC: not checked out yet");
    });
  });

  // ─── Host withdrawal ─────────────────────────────────────────────────────────

  describe("withdrawEarnings", () => {
    it("host can withdraw after booking", async () => {
      const roomId = await listDefaultRoom();
      await bookDefault(roomId);
      const cost     = PRICE_PER_HOUR * 2n;
      const expected = cost - (cost * 300n) / 10_000n;
      const before   = await ethers.provider.getBalance(host.address);
      const tx       = await roomChain.connect(host).withdrawEarnings();
      const rcpt     = await tx.wait();
      const gas      = rcpt.gasUsed * rcpt.gasPrice;
      const after    = await ethers.provider.getBalance(host.address);
      expect(after + gas - before).to.equal(expected);
    });

    it("reverts when nothing to withdraw", async () => {
      await expect(
        roomChain.connect(host).withdrawEarnings()
      ).to.be.revertedWith("RC: nothing to withdraw");
    });
  });

  // ─── Read helpers ────────────────────────────────────────────────────────────

  describe("Read helpers", () => {
    it("getBookingCost returns correct cost", async () => {
      const roomId = await listDefaultRoom();
      const [cost, hours] = await roomChain.getBookingCost(roomId, checkIn, checkOut);
      expect(hours).to.equal(2n);
      expect(cost).to.equal(PRICE_PER_HOUR * 2n);
    });

    it("isAvailable returns false after booking", async () => {
      const roomId = await listDefaultRoom();
      expect(await roomChain.isAvailable(roomId, checkIn, checkOut)).to.be.true;
      await bookDefault(roomId);
      expect(await roomChain.isAvailable(roomId, checkIn, checkOut)).to.be.false;
    });

    it("getGuestBookings returns guest bookings", async () => {
      const roomId = await listDefaultRoom();
      await bookDefault(roomId, guest);
      const ids = await roomChain.getGuestBookings(guest.address);
      expect(ids.length).to.equal(1);
    });
  });

  // ─── Admin ───────────────────────────────────────────────────────────────────

  describe("Admin", () => {
    it("owner updates platform fee", async () => {
      await roomChain.connect(owner).setPlatformFee(500n);
      expect(await roomChain.platformFeeBps()).to.equal(500n);
    });
    it("reverts fee > 1000 bps", async () => {
      await expect(roomChain.connect(owner).setPlatformFee(1001n)).to.be.revertedWith("RC: fee too high");
    });
    it("non-owner cannot set fee", async () => {
      await expect(roomChain.connect(attacker).setPlatformFee(0n)).to.be.reverted;
    });
    it("owner can pause and unpause", async () => {
      await roomChain.connect(owner).pause();
      await expect(
        roomChain.connect(host).listRoom("R", "L", "D", "U", PRICE_PER_HOUR, CAPACITY)
      ).to.be.reverted;
      await roomChain.connect(owner).unpause();
    });
  });
});
