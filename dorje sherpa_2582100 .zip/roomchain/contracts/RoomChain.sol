// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title RoomChain
 * @author RoomChain Team
 * @notice Decentralised room booking and management system on Ethereum
 * @dev Supports room listing, time-slot bookings, cancellations, and payouts
 */
contract RoomChain is Ownable, ReentrancyGuard, Pausable {

    // ─── Structs ────────────────────────────────────────────────────────────────

    struct Room {
        uint256 id;
        string  name;
        string  location;
        string  description;
        string  imageURI;
        uint256 pricePerHour;   // in wei
        uint256 capacity;       // max occupants
        address host;
        bool    active;
    }

    struct Booking {
        uint256 id;
        uint256 roomId;
        address guest;
        uint256 checkIn;        // Unix timestamp
        uint256 checkOut;       // Unix timestamp
        uint256 totalPaid;      // wei
        bool    cancelled;
        bool    completed;
        uint256 createdAt;
    }

    // ─── State ──────────────────────────────────────────────────────────────────

    uint256 private _nextRoomId    = 1;
    uint256 private _nextBookingId = 1;

    /// @notice Platform fee in basis points (300 = 3%)
    uint256 public platformFeeBps = 300;

    mapping(uint256 => Room)    public rooms;
    mapping(uint256 => Booking) public bookings;

    /// @dev roomId → list of bookingIds
    mapping(uint256 => uint256[]) private _roomBookings;

    /// @dev guest address → list of bookingIds
    mapping(address => uint256[]) private _guestBookings;

    /// @dev host address → claimable earnings
    mapping(address => uint256) public hostBalance;

    // ─── Events ─────────────────────────────────────────────────────────────────

    event RoomListed(
        uint256 indexed roomId,
        address indexed host,
        string  name,
        uint256 pricePerHour,
        uint256 capacity
    );

    event RoomUpdated(uint256 indexed roomId, bool active);

    event BookingCreated(
        uint256 indexed bookingId,
        uint256 indexed roomId,
        address indexed guest,
        uint256 checkIn,
        uint256 checkOut,
        uint256 totalPaid
    );

    event BookingCancelled(
        uint256 indexed bookingId,
        address indexed guest,
        uint256 refundAmount
    );

    event BookingCompleted(uint256 indexed bookingId, uint256 indexed roomId);

    event HostPaid(address indexed host, uint256 amount);

    // ─── Modifiers ───────────────────────────────────────────────────────────────

    modifier onlyHost(uint256 roomId) {
        require(rooms[roomId].host == msg.sender, "RC: not host");
        _;
    }

    modifier roomExists(uint256 roomId) {
        require(rooms[roomId].id != 0, "RC: room not found");
        _;
    }

    modifier bookingExists(uint256 bookingId) {
        require(bookings[bookingId].id != 0, "RC: booking not found");
        _;
    }

    // ─── Constructor ─────────────────────────────────────────────────────────────

    constructor() Ownable(msg.sender) {}

    // ─── Admin ───────────────────────────────────────────────────────────────────

    function setPlatformFee(uint256 newBps) external onlyOwner {
        require(newBps <= 1000, "RC: fee too high");
        platformFeeBps = newBps;
    }

    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function withdrawPlatformFees() external onlyOwner nonReentrant {
        uint256 total = address(this).balance;
        uint256 hostTotal = _totalHostBalances();
        require(total > hostTotal, "RC: no platform fees");
        uint256 fees = total - hostTotal;
        (bool ok, ) = owner().call{value: fees}("");
        require(ok, "RC: transfer failed");
    }

    // ─── Room management ────────────────────────────────────────────────────────

    /**
     * @notice List a new room for booking
     * @param name         Display name of the room
     * @param location     Physical address or description
     * @param description  What makes this room special
     * @param imageURI     IPFS or HTTPS image link
     * @param pricePerHour Price in wei per hour
     * @param capacity     Maximum number of guests
     */
    function listRoom(
        string calldata name,
        string calldata location,
        string calldata description,
        string calldata imageURI,
        uint256 pricePerHour,
        uint256 capacity
    ) external whenNotPaused returns (uint256 roomId) {
        require(bytes(name).length > 0,  "RC: empty name");
        require(pricePerHour > 0,        "RC: zero price");
        require(capacity > 0,            "RC: zero capacity");

        roomId = _nextRoomId++;

        rooms[roomId] = Room({
            id:           roomId,
            name:         name,
            location:     location,
            description:  description,
            imageURI:     imageURI,
            pricePerHour: pricePerHour,
            capacity:     capacity,
            host:         msg.sender,
            active:       true
        });

        emit RoomListed(roomId, msg.sender, name, pricePerHour, capacity);
    }

    /**
     * @notice Toggle room active/inactive (host only)
     */
    function setRoomActive(uint256 roomId, bool active)
        external
        roomExists(roomId)
        onlyHost(roomId)
    {
        rooms[roomId].active = active;
        emit RoomUpdated(roomId, active);
    }

    // ─── Booking ─────────────────────────────────────────────────────────────────

    /**
     * @notice Book a room for a time slot
     * @param roomId   Target room
     * @param checkIn  Unix timestamp — must be in future
     * @param checkOut Unix timestamp — must be after checkIn
     */
    function bookRoom(
        uint256 roomId,
        uint256 checkIn,
        uint256 checkOut
    )
        external
        payable
        nonReentrant
        whenNotPaused
        roomExists(roomId)
        returns (uint256 bookingId)
    {
        Room storage r = rooms[roomId];
        require(r.active,                       "RC: room not active");
        require(checkIn  > block.timestamp,     "RC: check-in in past");
        require(checkOut > checkIn,             "RC: invalid checkout");
        require(checkOut - checkIn >= 1 hours,  "RC: min 1 hour");
        require(checkOut - checkIn <= 30 days,  "RC: max 30 days");

        // Calculate expected price
        uint256 hours_  = (checkOut - checkIn) / 1 hours;
        uint256 expected = hours_ * r.pricePerHour;
        require(msg.value == expected, "RC: wrong ETH amount");

        // Check no overlapping booking exists for this room
        require(!_hasOverlap(roomId, checkIn, checkOut), "RC: slot unavailable");

        bookingId = _nextBookingId++;

        bookings[bookingId] = Booking({
            id:          bookingId,
            roomId:      roomId,
            guest:       msg.sender,
            checkIn:     checkIn,
            checkOut:    checkOut,
            totalPaid:   msg.value,
            cancelled:   false,
            completed:   false,
            createdAt:   block.timestamp
        });

        _roomBookings[roomId].push(bookingId);
        _guestBookings[msg.sender].push(bookingId);

        // Credit host (minus platform fee)
        uint256 fee      = (msg.value * platformFeeBps) / 10_000;
        uint256 hostCut  = msg.value - fee;
        hostBalance[r.host] += hostCut;

        emit BookingCreated(bookingId, roomId, msg.sender, checkIn, checkOut, msg.value);
    }

    /**
     * @notice Cancel a booking
     * Full refund if >48 h before check-in; 50% refund if >24 h; no refund otherwise
     */
    function cancelBooking(uint256 bookingId)
        external
        nonReentrant
        bookingExists(bookingId)
    {
        Booking storage b = bookings[bookingId];
        Room    storage r = rooms[b.roomId];

        require(b.guest == msg.sender,  "RC: not guest");
        require(!b.cancelled,           "RC: already cancelled");
        require(!b.completed,           "RC: already completed");
        require(block.timestamp < b.checkIn, "RC: stay already started");

        uint256 timeUntilCheckin = b.checkIn - block.timestamp;
        uint256 refundAmt;

        if (timeUntilCheckin >= 48 hours) {
            refundAmt = b.totalPaid;                    // 100% refund
        } else if (timeUntilCheckin >= 24 hours) {
            refundAmt = b.totalPaid / 2;                // 50% refund
        } else {
            refundAmt = 0;                              // no refund
        }

        b.cancelled = true;

        // Adjust host balance
        uint256 fee     = (b.totalPaid * platformFeeBps) / 10_000;
        uint256 hostCut = b.totalPaid - fee;
        hostBalance[r.host] -= hostCut;

        if (refundAmt > 0) {
            // Credit back what host would keep proportionally
            uint256 hostKeeps = b.totalPaid - refundAmt;
            uint256 hostKeepAfterFee = (hostKeeps * (10_000 - platformFeeBps)) / 10_000;
            hostBalance[r.host] += hostKeepAfterFee;

            (bool ok, ) = msg.sender.call{value: refundAmt}("");
            require(ok, "RC: refund failed");
        }

        emit BookingCancelled(bookingId, msg.sender, refundAmt);
    }

    /**
     * @notice Mark a booking as completed (host only, after checkout time)
     */
    function completeBooking(uint256 bookingId)
        external
        bookingExists(bookingId)
    {
        Booking storage b = bookings[bookingId];
        require(rooms[b.roomId].host == msg.sender, "RC: not host");
        require(!b.cancelled,  "RC: cancelled");
        require(!b.completed,  "RC: already completed");
        require(block.timestamp >= b.checkOut, "RC: not checked out yet");

        b.completed = true;
        emit BookingCompleted(bookingId, b.roomId);
    }

    /**
     * @notice Host withdraws accumulated earnings
     */
    function withdrawEarnings() external nonReentrant {
        uint256 amount = hostBalance[msg.sender];
        require(amount > 0, "RC: nothing to withdraw");
        hostBalance[msg.sender] = 0;
        (bool ok, ) = msg.sender.call{value: amount}("");
        require(ok, "RC: transfer failed");
        emit HostPaid(msg.sender, amount);
    }

    // ─── Read helpers ────────────────────────────────────────────────────────────

    function getRoomBookings(uint256 roomId)
        external view returns (uint256[] memory)
    {
        return _roomBookings[roomId];
    }

    function getGuestBookings(address guest)
        external view returns (uint256[] memory)
    {
        return _guestBookings[guest];
    }

    function totalRooms() external view returns (uint256) {
        return _nextRoomId - 1;
    }

    function totalBookings() external view returns (uint256) {
        return _nextBookingId - 1;
    }

    /**
     * @notice Calculate booking cost given a room and timestamps
     */
    function getBookingCost(
        uint256 roomId,
        uint256 checkIn,
        uint256 checkOut
    ) external view roomExists(roomId) returns (uint256 cost, uint256 numHours) {
        numHours = (checkOut - checkIn) / 1 hours;
        cost     = numHours * rooms[roomId].pricePerHour;
    }

    /**
     * @notice Check if a room is available for a given slot
     */
    function isAvailable(
        uint256 roomId,
        uint256 checkIn,
        uint256 checkOut
    ) external view returns (bool) {
        return !_hasOverlap(roomId, checkIn, checkOut);
    }

    // ─── Internal ────────────────────────────────────────────────────────────────

    function _hasOverlap(
        uint256 roomId,
        uint256 checkIn,
        uint256 checkOut
    ) internal view returns (bool) {
        uint256[] storage ids = _roomBookings[roomId];
        for (uint256 i = 0; i < ids.length; i++) {
            Booking storage b = bookings[ids[i]];
            if (b.cancelled) continue;
            // Overlap condition: not (new ends before existing OR new starts after existing)
            if (!(checkOut <= b.checkIn || checkIn >= b.checkOut)) {
                return true;
            }
        }
        return false;
    }

    function _totalHostBalances() internal view returns (uint256 total) {
        for (uint256 i = 1; i < _nextRoomId; i++) {
            total += hostBalance[rooms[i].host];
        }
    }

    receive() external payable {}
}
