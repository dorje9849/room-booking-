// scripts/deploy.js
const { ethers } = require("hardhat");
const fs   = require("fs");
const path = require("path");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying RoomChain with account:", deployer.address);
  console.log("Balance:", ethers.formatEther(await ethers.provider.getBalance(deployer.address)), "ETH");

  const RoomChain = await ethers.getContractFactory("RoomChain");
  const roomChain = await RoomChain.deploy();
  await roomChain.waitForDeployment();

  const address = await roomChain.getAddress();
  console.log("✅ RoomChain deployed to:", address);

  const network = await ethers.provider.getNetwork();
  if (network.chainId === 31337n) {
    console.log("\n🌱 Seeding demo rooms...");
    await seedDemoRooms(roomChain);
  }

  // Write artifact for frontend
  const artifact = {
    address,
    network: network.name,
    chainId: network.chainId.toString(),
    deployedAt: new Date().toISOString(),
    abi: JSON.parse(
      fs.readFileSync(
        path.join(__dirname, "../artifacts/contracts/RoomChain.sol/RoomChain.json"),
        "utf8"
      )
    ).abi,
  };

  const outDir = path.join(__dirname, "../frontend/src/contracts");
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(
    path.join(outDir, "RoomChain.json"),
    JSON.stringify(artifact, null, 2)
  );
  console.log("📄 Artifact written to frontend/src/contracts/RoomChain.json");
}

async function seedDemoRooms(contract) {
  const rooms = [
    {
      name:         "The Executive Suite",
      location:     "Floor 12, Canary Wharf Tower, London",
      description:  "Premium boardroom with panoramic Thames views, 4K display wall, video conferencing, and dedicated concierge. Seats up to 20 executives.",
      imageURI:     "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800",
      pricePerHour: ethers.parseEther("0.05"),
      capacity:     20,
    },
    {
      name:         "Creative Studio Alpha",
      location:     "Shoreditch Tech Hub, London",
      description:  "Open-plan creative workspace with whiteboards, bean bags, and breakout zones. Perfect for agile sprints and design thinking workshops.",
      imageURI:     "https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800",
      pricePerHour: ethers.parseEther("0.02"),
      capacity:     15,
    },
    {
      name:         "Conference Room Bravo",
      location:     "King's Cross Innovation Centre, London",
      description:  "Professional conference room with dual 4K screens, hybrid meeting setup, and catering facilities. Ideal for client presentations.",
      imageURI:     "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=800",
      pricePerHour: ethers.parseEther("0.03"),
      capacity:     30,
    },
    {
      name:         "Quiet Focus Pod",
      location:     "WeWork Waterloo, London",
      description:  "Soundproofed individual pod for deep work, video calls, and focused sessions. Ergonomic setup with sit-stand desk and natural light.",
      imageURI:     "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=800",
      pricePerHour: ethers.parseEther("0.008"),
      capacity:     2,
    },
    {
      name:         "Event Hall Delta",
      location:     "South Bank Conference Centre, London",
      description:  "Full event hall with stage, PA system, and 300-seat theatre layout. Suitable for product launches, seminars, and corporate events.",
      imageURI:     "https://images.unsplash.com/photo-1511578314322-379afb476865?w=800",
      pricePerHour: ethers.parseEther("0.1"),
      capacity:     300,
    },
  ];

  for (const r of rooms) {
    const tx = await contract.listRoom(
      r.name, r.location, r.description, r.imageURI, r.pricePerHour, r.capacity
    );
    await tx.wait();
    console.log(`  ✔ Listed: "${r.name}"`);
  }
}

main()
  .then(() => process.exit(0))
  .catch((err) => { console.error(err); process.exit(1); });
