// src/utils/helpers.js
import { ethers } from "ethers";
import { format, formatDistanceToNow } from "date-fns";

export const formatEth = (wei) => {
  try { return parseFloat(ethers.formatEther(wei.toString())).toFixed(4) + " ETH"; }
  catch { return "—"; }
};

export const formatDate   = (ts) => format(new Date(Number(ts) * 1000), "EEE dd MMM yyyy · HH:mm");
export const formatDateSh = (ts) => format(new Date(Number(ts) * 1000), "dd MMM · HH:mm");
export const timeFromNow  = (ts) => formatDistanceToNow(new Date(Number(ts) * 1000), { addSuffix: true });
export const shortAddr    = (a)  => a ? `${a.slice(0,6)}…${a.slice(-4)}` : "";

export const parseTxError = (err) => {
  const r = err?.reason || err?.data?.message || err?.error?.data?.message || err?.message || "Transaction failed";
  return r.replace(/^execution reverted:\s*/i, "").replace(/^RC:\s*/i, "");
};

export const calcHours = (checkIn, checkOut) =>
  Math.floor((Number(checkOut) - Number(checkIn)) / 3600);

export const calcCost = (pricePerHour, checkIn, checkOut) => {
  const hours = calcHours(checkIn, checkOut);
  return BigInt(hours) * BigInt(pricePerHour.toString());
};

export const toUnix = (datetimeLocal) =>
  Math.floor(new Date(datetimeLocal).getTime() / 1000);

export const toDatetimeLocal = (unixTs) => {
  const d = new Date(Number(unixTs) * 1000);
  return d.toISOString().slice(0, 16);
};
