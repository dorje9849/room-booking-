import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useWeb3 } from "../hooks/useWeb3";
import { formatEth, roomTypeLabel, roomTypeIcon, ROOM_TYPE_COLORS } from "../utils/helpers";

const s = {
  page: { padding: "3rem 2rem", maxWidth: 1200, margin: "0 auto" },
  header: { marginBottom: "2rem" },
  title: { fontSize: "2.25rem", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "0.4rem" },
  subtitle: { color: "var(--muted)", fontSize: "0.95rem" },
  filterRow: { display: "flex", gap: "0.5rem", marginBottom: "2rem", flexWrap: "wrap" },
  filterBtn: {
    padding: "0.4rem 1rem", borderRadius: "50px",
    border: "1px solid var(--border)", background: "transparent",
    color: "var(--muted)", fontSize: "0.82rem", cursor: "pointer", transition: "all 0.2s",
  },
  filterActive: { border: "1px solid var(--emerald)", background: "rgba(5,150,105,0.12)", color: "var(--emerald-lt)" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(310px, 1fr))", gap: "1.5rem" },
  card: {
    borderRadius: "var(--radius)", border: "1px solid var(--border)",
    background: "var(--bg2)", overflow: "hidden",
    transition: "border-color 0.3s, transform 0.2s, box-shadow 0.2s", cursor: "pointer",
  },
  img: { width: "100%", height: 175, objectFit: "cover", display: "block" },
  imgPlaceholder: {
    width: "100%", height: 175,
    background: "linear-gradient(135deg, #1a1a2a, #0f1f1a)",
    display: "flex", alignItems: "center", justifyContent: "center", fontSize: "3rem",
  },
  cardBody: { padding: "1.25rem" },
  typeRow: { display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.6rem" },
  typeBadge: {
    fontSize: "0.68rem", fontWeight: 700, letterSpacing: "0.06em",
    padding: "0.2rem 0.6rem", borderRadius: "50px", textTransform: "uppercase",
  },
  cardName: { fontWeight: 700, fontSize: "1.05rem", marginBottom: "0.35rem", lineHeight: 1.3 },
  cardLocation: { color: "var(--muted)", fontSize: "0.82rem", marginBottom: "1rem" },
  cardFooter: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "0.75rem" },
  price: { fontFamily: "'DM Mono', monospace", color: "var(--emerald-lt)", fontSize: "0.95rem", fontWeight: 500 },
  guestsBadge: {
    fontSize: "0.75rem", color: "var(--muted)",
    padding: "0.2rem 0.6rem", border: "1px solid var(--border)", borderRadius: "6px",
  },
  unavailBadge: {
    fontSize: "0.68rem", fontWeight: 700, padding: "0.2rem 0.6rem",
    borderRadius: "50px", background: "rgba(225,29,72,0.12)", color: "#fb7185",
    letterSpacing: "0.05em",
  },
  empty: { textAlign: "center", color: "var(--muted)", padding: "4rem", fontSize: "1rem" },
  loading: { textAlign: "center", color: "var(--muted)", padding: "4rem" },
};

const FILTERS = ["All", "Single", "Double", "Suite", "Conference", "Available"];

export default function RoomsPage() {
  const { getReadOnlyContract } = useWeb3();
  const [rooms,   setRooms]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter,  setFilter]  = useState("All");

  useEffect(() => { loadRooms(); }, []); // eslint-disable-line

  const loadRooms = async () => {
    setLoading(true);
    try {
      const c     = getReadOnlyContract();
      if (!c) { setLoading(false); return; }
      const total = Number(await c.totalRooms());
      const rs    = [];
      for (let i = 1; i <= total; i++) {
        const r = await c.rooms(i);
        rs.push(r);
      }
      setRooms(rs.reverse());
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const filtered = rooms.filter(r => {
    if (filter === "Available") return r.available;
    if (filter === "Single")    return Number(r.roomType) === 0;
    if (filter === "Double")    return Number(r.roomType) === 1;
    if (filter === "Suite")     return Number(r.roomType) === 2;
    if (filter === "Conference") return Number(r.roomType) === 3;
    return true;
  });

  return (
    <div style={s.page}>
      <div style={s.header}>
        <h1 style={s.title}>All Rooms</h1>
        <p style={s.subtitle}>Decentralised room listings on Ethereum</p>
      </div>

      <div style={s.filterRow}>
        {FILTERS.map(f => (
          <button key={f} style={{ ...s.filterBtn, ...(filter === f ? s.filterActive : {}) }}
            onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>

      {loading ? (
        <div style={s.loading}>⟳ Loading rooms from chain…</div>
      ) : filtered.length === 0 ? (
        <div style={s.empty}>No rooms found.</div>
      ) : (
        <div style={s.grid}>
          {filtered.map(r => {
            const typeIdx = Number(r.roomType);
            const color   = ROOM_TYPE_COLORS[typeIdx];
            return (
              <Link key={r.id.toString()} to={`/rooms/${r.id}`} style={{ textDecoration: "none", color: "inherit" }}>
                <div style={s.card}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--emerald)"; e.currentTarget.style.transform = "translateY(-5px)"; e.currentTarget.style.boxShadow = "0 14px 36px rgba(5,150,105,0.18)"; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border)";  e.currentTarget.style.transform = "translateY(0)";    e.currentTarget.style.boxShadow = "none"; }}
                >
                  {r.imageURI ? (
                    <img src={r.imageURI} alt={r.name} style={s.img} onError={e => { e.target.style.display = "none"; }} />
                  ) : (
                    <div style={s.imgPlaceholder}>{roomTypeIcon(r.roomType)}</div>
                  )}
                  <div style={s.cardBody}>
                    <div style={s.typeRow}>
                      <span style={{ ...s.typeBadge, background: color + "22", color }}>
                        {roomTypeIcon(r.roomType)} {roomTypeLabel(r.roomType)}
                      </span>
                      {!r.available && <span style={s.unavailBadge}>Unavailable</span>}
                    </div>
                    <div style={s.cardName}>{r.name}</div>
                    <div style={s.cardLocation}>📍 {r.location}</div>
                    <div style={s.cardFooter}>
                      <span style={s.price}>{formatEth(r.pricePerNight)}<span style={{ color: "var(--muted)", fontSize: "0.75rem" }}> / night</span></span>
                      <span style={s.guestsBadge}>👥 {r.maxGuests.toString()} guests</span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
