import React, { useEffect, useState, useCallback } from "react";
import toast from "react-hot-toast";
import { useWeb3 } from "../hooks/useWeb3";
import { formatEth, formatDate, roomTypeIcon, roomTypeLabel, parseTxError, shortAddr } from "../utils/helpers";

const s = {
  page: { maxWidth: 980, margin: "0 auto", padding: "3rem 2rem" },
  title: { fontSize: "2.25rem", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "0.4rem" },
  subtitle: { color: "var(--muted)", marginBottom: "2.5rem", fontSize: "0.875rem" },
  earningsCard: {
    background: "linear-gradient(135deg, rgba(5,150,105,0.18), rgba(217,119,6,0.1))",
    border: "1px solid rgba(52,211,153,0.2)", borderRadius: "var(--radius)",
    padding: "2rem", marginBottom: "2.5rem",
    display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "1rem",
  },
  earningsLabel: { fontSize: "0.72rem", color: "var(--muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.4rem" },
  earningsVal: {
    fontFamily: "'DM Mono', monospace", fontSize: "2.2rem", fontWeight: 500,
    background: "linear-gradient(135deg, var(--emerald-lt), var(--gold-lt))",
    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
  },
  withdrawBtn: {
    padding: "0.8rem 2.25rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 800, fontSize: "0.9rem", cursor: "pointer",
    transition: "opacity 0.2s", boxShadow: "0 0 24px rgba(5,150,105,0.3)",
  },
  statsRow: {
    display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
    gap: "1rem", marginBottom: "2.5rem",
  },
  statCard: { padding: "1.25rem", borderRadius: "10px", border: "1px solid var(--border)", background: "var(--bg2)" },
  statLabel: { fontSize: "0.68rem", color: "var(--muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.4rem" },
  statVal: { fontFamily: "'DM Mono', monospace", fontSize: "1.5rem", fontWeight: 500, color: "var(--emerald-lt)" },
  sectionTitle: { fontSize: "1.15rem", fontWeight: 700, marginBottom: "1.1rem", letterSpacing: "-0.02em" },
  table: { width: "100%", borderCollapse: "collapse", fontSize: "0.82rem" },
  th: {
    textAlign: "left", padding: "0.65rem 1rem",
    color: "var(--muted)", fontSize: "0.68rem", letterSpacing: "0.08em",
    textTransform: "uppercase", borderBottom: "1px solid var(--border)",
  },
  td: { padding: "0.9rem 1rem", borderBottom: "1px solid var(--border)", verticalAlign: "middle" },
  mono: { fontFamily: "'DM Mono', monospace", fontSize: "0.78rem" },
  toggleBtn: {
    padding: "0.35rem 0.75rem", borderRadius: "6px", fontSize: "0.72rem", fontWeight: 600,
    cursor: "pointer", border: "1px solid var(--border)", background: "var(--bg3)",
    color: "var(--text)", transition: "border-color 0.2s",
  },
  notConnected: { textAlign: "center", color: "var(--muted)", padding: "6rem 2rem" },
  connectBtn: {
    marginTop: "1rem", padding: "0.8rem 2rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: "0.95rem",
  },
  empty: { color: "var(--muted)", padding: "2rem 0", textAlign: "center" },
};

export default function Dashboard() {
  const { contract, account, connect, isConnected, getReadOnlyContract } = useWeb3();
  const [earnings,    setEarnings]    = useState("0");
  const [myRooms,     setMyRooms]     = useState([]);
  const [roomBookings, setRoomBookings] = useState({});
  const [loading,     setLoading]     = useState(true);
  const [withdrawing, setWithdrawing] = useState(false);
  const [toggling,    setToggling]    = useState(null);

  const load = useCallback(async () => {
    if (!account) return;
    setLoading(true);
    try {
      const c   = contract || getReadOnlyContract();
      if (!c) return;
      const bal = await c.ownerBalance(account);
      setEarnings(bal.toString());
      const total = Number(await c.totalRooms());
      const rs    = [];
      const rb    = {};
      for (let i = 1; i <= total; i++) {
        const r = await c.rooms(i);
        if (r.owner.toLowerCase() === account.toLowerCase()) {
          rs.push(r);
          const bids = await c.getRoomBookings(i);
          rb[r.id.toString()] = bids.length;
        }
      }
      setMyRooms(rs.reverse());
      setRoomBookings(rb);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, [account, contract, getReadOnlyContract]);

  useEffect(() => { load(); }, [load]);

  const handleWithdraw = async () => {
    if (!contract) return;
    setWithdrawing(true);
    const tid = toast.loading("Withdrawing earnings…");
    try {
      const tx = await contract.withdrawEarnings();
      await tx.wait();
      toast.success("Earnings withdrawn to wallet!", { id: tid });
      await load();
    } catch (err) {
      toast.error(parseTxError(err), { id: tid });
    } finally { setWithdrawing(false); }
  };

  const handleToggle = async (roomId, currentlyAvailable) => {
    if (!contract) return;
    setToggling(roomId.toString());
    const tid = toast.loading("Updating availability…");
    try {
      const tx = await contract.setRoomAvailability(roomId, !currentlyAvailable);
      await tx.wait();
      toast.success(`Room marked ${!currentlyAvailable ? "available" : "unavailable"}.`, { id: tid });
      await load();
    } catch (err) {
      toast.error(parseTxError(err), { id: tid });
    } finally { setToggling(null); }
  };

  if (!isConnected) return (
    <div style={s.notConnected}>
      <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>📊</div>
      <h2 style={{ marginBottom: "0.5rem" }}>Host Dashboard</h2>
      <p>Connect your wallet to manage your rooms and earnings.</p>
      <button style={s.connectBtn} onClick={() => connect()}>Connect Wallet</button>
    </div>
  );

  const totalBookingCount = Object.values(roomBookings).reduce((a, b) => a + b, 0);
  const activeRooms       = myRooms.filter(r => r.available).length;

  return (
    <div style={s.page}>
      <h1 style={s.title}>Host Dashboard</h1>
      <p style={s.subtitle}>{shortAddr(account)}</p>

      {/* Stats */}
      <div style={s.statsRow}>
        {[
          { label: "My Rooms",       val: myRooms.length        },
          { label: "Active",         val: activeRooms            },
          { label: "Total Bookings", val: totalBookingCount      },
        ].map(({ label, val }) => (
          <div key={label} style={s.statCard}>
            <div style={s.statLabel}>{label}</div>
            <div style={s.statVal}>{val}</div>
          </div>
        ))}
      </div>

      {/* Earnings */}
      <div style={s.earningsCard}>
        <div>
          <div style={s.earningsLabel}>Claimable Earnings</div>
          <div style={s.earningsVal}>{formatEth(earnings)}</div>
        </div>
        <button
          style={{ ...s.withdrawBtn, opacity: withdrawing || earnings === "0" ? 0.55 : 1 }}
          onClick={handleWithdraw} disabled={withdrawing || earnings === "0"}
          onMouseEnter={e => { e.target.style.opacity = "0.82"; }}
          onMouseLeave={e => { e.target.style.opacity = withdrawing || earnings === "0" ? "0.55" : "1"; }}
        >
          {withdrawing ? "Withdrawing…" : "Withdraw ETH →"}
        </button>
      </div>

      {/* Rooms table */}
      <div style={s.sectionTitle}>My Rooms</div>
      {loading ? (
        <p style={{ color: "var(--muted)" }}>Loading…</p>
      ) : myRooms.length === 0 ? (
        <p style={s.empty}>No rooms listed. <a href="/list" style={{ color: "var(--emerald-lt)" }}>List one →</a></p>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table style={s.table}>
            <thead>
              <tr>{["ID", "Room", "Type", "Bookings", "Price/Night", "Status", "Action"].map(h => (
                <th key={h} style={s.th}>{h}</th>
              ))}</tr>
            </thead>
            <tbody>
              {myRooms.map(r => (
                <tr key={r.id.toString()}>
                  <td style={{ ...s.td, ...s.mono }}>#{r.id.toString()}</td>
                  <td style={s.td}>
                    <a href={`/rooms/${r.id}`} style={{ color: "var(--text)", fontWeight: 600 }}>{r.name}</a>
                    <div style={{ color: "var(--muted)", fontSize: "0.72rem" }}>{r.location}</div>
                  </td>
                  <td style={s.td}>{roomTypeIcon(r.roomType)} {roomTypeLabel(r.roomType)}</td>
                  <td style={{ ...s.td, ...s.mono }}>{roomBookings[r.id.toString()] || 0}</td>
                  <td style={{ ...s.td, ...s.mono }}>{formatEth(r.pricePerNight)}</td>
                  <td style={s.td}>
                    <span style={{ fontSize: "0.75rem", fontWeight: 600, color: r.available ? "var(--emerald-lt)" : "#fb7185" }}>
                      {r.available ? "✅ Available" : "❌ Unavailable"}
                    </span>
                  </td>
                  <td style={s.td}>
                    <button style={s.toggleBtn}
                      onClick={() => handleToggle(r.id, r.available)}
                      disabled={toggling === r.id.toString()}
                      onMouseEnter={e => { e.target.style.borderColor = "var(--emerald)"; }}
                      onMouseLeave={e => { e.target.style.borderColor = "var(--border)"; }}
                    >
                      {toggling === r.id.toString() ? "…" : r.available ? "Disable" : "Enable"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
