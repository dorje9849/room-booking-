import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ethers } from "ethers";
import toast from "react-hot-toast";
import { useWeb3 } from "../hooks/useWeb3";
import { parseTxError, ROOM_TYPES } from "../utils/helpers";

const s = {
  page: { maxWidth: 700, margin: "0 auto", padding: "3rem 2rem" },
  title: { fontSize: "2.25rem", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "0.4rem" },
  subtitle: { color: "var(--muted)", marginBottom: "2.5rem", fontSize: "0.875rem" },
  form: { background: "var(--bg2)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: "2.25rem" },
  section: { marginBottom: "1.5rem" },
  label: { display: "block", fontSize: "0.72rem", fontWeight: 600, color: "var(--muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.5rem" },
  input: {
    width: "100%", padding: "0.75rem 0.9rem", borderRadius: "9px",
    border: "1px solid var(--border)", background: "var(--bg3)", color: "var(--text)",
    fontSize: "0.9rem", fontFamily: "inherit", outline: "none", transition: "border-color 0.2s", boxSizing: "border-box",
  },
  textarea: {
    width: "100%", padding: "0.75rem 0.9rem", borderRadius: "9px",
    border: "1px solid var(--border)", background: "var(--bg3)", color: "var(--text)",
    fontSize: "0.9rem", fontFamily: "inherit", outline: "none", minHeight: 110, resize: "vertical",
    boxSizing: "border-box", transition: "border-color 0.2s",
  },
  select: {
    width: "100%", padding: "0.75rem 0.9rem", borderRadius: "9px",
    border: "1px solid var(--border)", background: "var(--bg3)", color: "var(--text)",
    fontSize: "0.9rem", fontFamily: "inherit", outline: "none", boxSizing: "border-box",
  },
  row: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" },
  hint: { fontSize: "0.72rem", color: "var(--muted)", marginTop: "0.35rem" },
  submitBtn: {
    width: "100%", padding: "0.9rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 800, fontSize: "0.95rem", cursor: "pointer",
    marginTop: "1rem", transition: "opacity 0.2s", boxShadow: "0 0 24px rgba(5,150,105,0.28)",
  },
  feeInfo: {
    marginTop: "1.5rem", padding: "0.9rem", borderRadius: "9px",
    border: "1px solid rgba(5,150,105,0.2)", background: "rgba(5,150,105,0.05)",
    fontSize: "0.78rem", color: "var(--muted)", lineHeight: 1.6,
  },
  notConnected: { textAlign: "center", color: "var(--muted)", padding: "4rem" },
  connectBtn: {
    marginTop: "1rem", padding: "0.8rem 2rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: "0.95rem",
  },
  previewImg: { width: "100%", height: 150, objectFit: "cover", borderRadius: "9px", marginBottom: "1.5rem" },
};

const INIT = { name: "", location: "", description: "", imageURI: "", roomType: "1", priceEth: "", maxGuests: "" };
const focus = e => { e.target.style.borderColor = "var(--emerald)"; };
const blur  = e => { e.target.style.borderColor = "var(--border)"; };

export default function ListRoom() {
  const { contract, connect, isConnected } = useWeb3();
  const navigate = useNavigate();
  const [form, setForm] = useState(INIT);
  const [submitting, setSubmitting] = useState(false);

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async e => {
    e.preventDefault();
    if (!contract) return;
    const { name, location, description, imageURI, roomType, priceEth, maxGuests } = form;
    if (!name || !location || !description || !priceEth || !maxGuests) {
      toast.error("Please fill in all required fields."); return;
    }
    if (parseFloat(priceEth) <= 0) { toast.error("Price must be > 0 ETH."); return; }
    if (parseInt(maxGuests) <= 0)  { toast.error("Max guests must be > 0."); return; }

    setSubmitting(true);
    const tid = toast.loading("Listing room on-chain…");
    try {
      const priceWei = ethers.parseEther(priceEth.toString());
      const tx = await contract.listRoom(
        name.trim(), location.trim(), description.trim(),
        imageURI.trim(), parseInt(roomType), priceWei, parseInt(maxGuests)
      );
      toast.loading("Waiting for confirmation…", { id: tid });
      const receipt = await tx.wait();
      const log     = receipt.logs.find(l => { try { contract.interface.parseLog(l); return true; } catch { return false; } });
      const parsed  = contract.interface.parseLog(log);
      const newId   = parsed.args.roomId;
      toast.success("🏨 Room listed!", { id: tid, duration: 4000 });
      navigate(`/rooms/${newId}`);
    } catch (err) {
      toast.error(parseTxError(err), { id: tid });
    } finally {
      setSubmitting(false);
    }
  };

  if (!isConnected) return (
    <div style={{ ...s.notConnected, ...s.page }}>
      <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🏨</div>
      <h2 style={{ marginBottom: "0.5rem" }}>Connect to List a Room</h2>
      <p>You need a connected wallet to list rooms.</p>
      <button style={s.connectBtn} onClick={() => connect()}>Connect Wallet</button>
    </div>
  );

  return (
    <div style={s.page}>
      <h1 style={s.title}>List a Room</h1>
      <p style={s.subtitle}>Add your property to the RoomChain blockchain.</p>

      {form.imageURI && (
        <img src={form.imageURI} alt="Preview" style={s.previewImg}
          onError={e => { e.target.style.display = "none"; }} />
      )}

      <form style={s.form} onSubmit={handleSubmit}>
        <div style={s.section}>
          <label style={s.label}>Room Name *</label>
          <input style={s.input} value={form.name} onChange={set("name")} placeholder="e.g. The Horizon Suite" onFocus={focus} onBlur={blur} />
        </div>

        <div style={s.section}>
          <label style={s.label}>Location *</label>
          <input style={s.input} value={form.location} onChange={set("location")} placeholder="e.g. Canary Wharf, London" onFocus={focus} onBlur={blur} />
        </div>

        <div style={s.section}>
          <label style={s.label}>Description *</label>
          <textarea style={s.textarea} value={form.description} onChange={set("description")} placeholder="Describe your room for guests…" onFocus={focus} onBlur={blur} />
        </div>

        <div style={s.section}>
          <label style={s.label}>Image URL</label>
          <input style={s.input} value={form.imageURI} onChange={set("imageURI")} placeholder="https://… or ipfs://…" onFocus={focus} onBlur={blur} />
          <p style={s.hint}>Unsplash or IPFS link. Optional but recommended.</p>
        </div>

        <div style={{ ...s.section, ...s.row }}>
          <div>
            <label style={s.label}>Room Type *</label>
            <select style={s.select} value={form.roomType} onChange={set("roomType")}>
              {ROOM_TYPES.map((t, i) => <option key={i} value={i}>{t}</option>)}
            </select>
          </div>
          <div>
            <label style={s.label}>Max Guests *</label>
            <input type="number" min="1" style={s.input} value={form.maxGuests} onChange={set("maxGuests")} placeholder="e.g. 2" onFocus={focus} onBlur={blur} />
          </div>
        </div>

        <div style={s.section}>
          <label style={s.label}>Price Per Night (ETH) *</label>
          <input type="number" step="0.001" min="0.001" style={s.input} value={form.priceEth} onChange={set("priceEth")} placeholder="e.g. 0.05" onFocus={focus} onBlur={blur} />
        </div>

        <div style={s.feeInfo}>
          ℹ️ <strong>Your earnings:</strong> You receive 97% of each booking. Withdraw anytime from the Dashboard. Refund policy is enforced automatically by the smart contract.
        </div>

        <button type="submit" style={{ ...s.submitBtn, opacity: submitting ? 0.65 : 1 }} disabled={submitting}
          onMouseEnter={e => { if (!submitting) e.target.style.opacity = "0.82"; }}
          onMouseLeave={e => { e.target.style.opacity = submitting ? "0.65" : "1"; }}
        >
          {submitting ? "Deploying to Chain…" : "List Room on Ethereum →"}
        </button>
      </form>
    </div>
  );
}
