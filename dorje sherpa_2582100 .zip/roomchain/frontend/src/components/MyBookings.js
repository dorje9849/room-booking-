import React, { useEffect, useState, useCallback } from "react";
import toast from "react-hot-toast";
import { useWeb3 } from "../hooks/useWeb3";
import { formatEth, formatDate, roomTypeIcon, parseTxError, shortAddr } from "../utils/helpers";

const s = {
  page: { maxWidth: 980, margin: "0 auto", padding: "3rem 2rem" },
  title: { fontSize: "2.25rem", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "0.4rem" },
  subtitle: { color: "var(--muted)", marginBottom: "2.5rem", fontSize: "0.875rem" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(290px, 1fr))", gap: "1.25rem" },
  card: { borderRadius: "var(--radius)", border: "1px solid var(--border)", background: "var(--bg2)", overflow: "hidden", transition: "border-color 0.3s" },
  cardTop: {
    background: "linear-gradient(135deg, rgba(5,150,105,0.12), rgba(217,119,6,0.08))",
    padding: "1.25rem 1.5rem", borderBottom: "1px solid var(--border)", position: "relative",
  },
  bookingId: { fontFamily: "'DM Mono', monospace", fontSize: "0.65rem", color: "var(--emerald-lt)", letterSpacing: "0.1em", marginBottom: "0.4rem" },
  roomName: { fontWeight: 700, fontSize: "1rem", lineHeight: 1.3, marginBottom: "0.3rem" },
  location: { fontSize: "0.78rem", color: "var(--muted)" },
  cardBody: { padding: "1.25rem 1.5rem" },
  row: { display: "flex", justifyContent: "space-between", marginBottom: "0.45rem", fontSize: "0.82rem" },
  label: { color: "var(--muted)" },
  val: { fontFamily: "'DM Mono', monospace", fontSize: "0.78rem" },
  statusBadge: {
    display: "inline-block", padding: "0.2rem 0.65rem", borderRadius: "50px",
    fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "0.9rem",
  },
  actions: { display: "flex", gap: "0.5rem", marginTop: "1rem" },
  cancelBtn: {
    flex: 1, padding: "0.55rem", borderRadius: "8px",
    border: "1px solid rgba(225,29,72,0.5)", background: "transparent",
    color: "#fb7185", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer", transition: "background 0.2s",
  },
  viewBtn: {
    flex: 1, padding: "0.55rem", borderRadius: "8px",
    border: "1px solid var(--border)", background: "var(--bg3)",
    color: "var(--text)", fontSize: "0.78rem", fontWeight: 600, cursor: "pointer", transition: "border-color 0.2s",
  },
  notConnected: { textAlign: "center", color: "var(--muted)", padding: "6rem 2rem" },
  connectBtn: {
    marginTop: "1rem", padding: "0.8rem 2rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 700, cursor: "pointer", fontSize: "0.95rem",
  },
};

function getStatus(b) {
  if (b.cancelled)  return { label: "Cancelled", bg: "#1f1520", color: "#fb7185" };
  if (b.checkedOut) return { label: "Checked Out", bg: "#0f1f1a", color: "#34d399" };
  if (b.checkedIn)  return { label: "Checked In", bg: "#0f1f1a", color: "#34d399" };
  return                   { label: "Confirmed",  bg: "rgba(5,150,105,0.15)", color: "var(--emerald-lt)" };
}

export default function MyBookings() {
  const { contract, account, connect, isConnected, getReadOnlyContract } = useWeb3();
  const [bookings, setBookings] = useState([]);
  const [rooms,    setRooms]    = useState({});
  const [loading,  setLoading]  = useState(true);

  const load = useCallback(async () => {
    if (!account) return;
    setLoading(true);
    try {
      const c   = contract || getReadOnlyContract();
      if (!c) return;
      const ids = await c.getGuestBookings(account);
      const bs  = [];
      const rc  = {};
      for (const id of ids) {
        const b = await c.bookings(id);
        bs.push(b);
        if (!rc[b.roomId.toString()]) {
          rc[b.roomId.toString()] = await c.rooms(b.roomId);
        }
      }
      setBookings(bs.reverse());
      setRooms(rc);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  }, [account, contract, getReadOnlyContract]);

  useEffect(() => { load(); }, [load]);

  const handleCancel = async (bookingId) => {
    if (!contract) return;
    const tid = toast.loading("Cancelling booking…");
    try {
      const tx = await contract.cancelBooking(bookingId);
      await tx.wait();
      toast.success("Booking cancelled. Refund processed.", { id: tid });
      await load();
    } catch (err) {
      toast.error(parseTxError(err), { id: tid });
    }
  };

  if (!isConnected) return (
    <div style={s.notConnected}>
      <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🏨</div>
      <h2 style={{ marginBottom: "0.5rem" }}>Connect your wallet</h2>
      <p>Connect to view your bookings.</p>
      <button style={s.connectBtn} onClick={() => connect()}>Connect Wallet</button>
    </div>
  );

  return (
    <div style={s.page}>
      <h1 style={s.title}>My Bookings</h1>
      <p style={s.subtitle}>{account?.slice(0, 6)}…{account?.slice(-4)}</p>

      {loading ? (
        <p style={{ color: "var(--muted)" }}>Loading bookings…</p>
      ) : bookings.length === 0 ? (
        <p style={{ color: "var(--muted)", marginTop: "3rem" }}>
          No bookings yet. <a href="/rooms" style={{ color: "var(--emerald-lt)" }}>Browse rooms →</a>
        </p>
      ) : (
        <div style={s.grid}>
          {bookings.map(b => {
            const room   = rooms[b.roomId.toString()];
            const status = getStatus(b);
            const isActive = !b.cancelled && !b.checkedOut;
            return (
              <div key={b.id.toString()} style={s.card}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--emerald)"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border)"; }}
              >
                <div style={s.cardTop}>
                  <div style={s.bookingId}>BOOKING #{b.id.toString()}</div>
                  <div style={s.roomName}>{roomTypeIcon(room?.roomType)} {room?.name || `Room #${b.roomId}`}</div>
                  <div style={s.location}>📍 {room?.location || "—"}</div>
                </div>
                <div style={s.cardBody}>
                  <div style={{ ...s.statusBadge, background: status.bg, color: status.color }}>{status.label}</div>
                  <div style={s.row}><span style={s.label}>Check-in</span><span style={s.val}>{formatDate(b.checkIn)}</span></div>
                  <div style={s.row}><span style={s.label}>Check-out</span><span style={s.val}>{formatDate(b.checkOut)}</span></div>
                  <div style={s.row}><span style={s.label}>Paid</span><span style={s.val}>{formatEth(b.totalPaid)}</span></div>
                  <div style={s.row}><span style={s.label}>Host</span><span style={s.val}>{shortAddr(room?.owner || "")}</span></div>
                  {isActive && (
                    <div style={s.actions}>
                      <button style={s.viewBtn}
                        onClick={() => window.location.href = `/rooms/${b.roomId}`}
                        onMouseEnter={e => { e.target.style.borderColor = "var(--emerald)"; }}
                        onMouseLeave={e => { e.target.style.borderColor = "var(--border)"; }}
                      >View Room</button>
                      <button style={s.cancelBtn}
                        onClick={() => handleCancel(b.id)}
                        onMouseEnter={e => { e.target.style.background = "rgba(225,29,72,0.1)"; }}
                        onMouseLeave={e => { e.target.style.background = "transparent"; }}
                      >Cancel</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
