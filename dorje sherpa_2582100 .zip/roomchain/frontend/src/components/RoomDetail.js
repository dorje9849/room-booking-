import React, { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ethers } from "ethers";
import toast from "react-hot-toast";
import { useWeb3 } from "../hooks/useWeb3";
import {
  formatEth, formatDate, roomTypeLabel, roomTypeIcon,
  nightsBetween, toUnix, parseTxError, shortAddr, ROOM_TYPE_COLORS,
} from "../utils/helpers";

const s = {
  page: { maxWidth: 1100, margin: "0 auto", padding: "3rem 2rem" },
  back: { color: "var(--emerald-lt)", fontSize: "0.875rem", cursor: "pointer", marginBottom: "2rem", display: "inline-block" },
  layout: { display: "grid", gridTemplateColumns: "1fr 360px", gap: "3rem", alignItems: "start" },
  img: { width: "100%", borderRadius: "var(--radius)", maxHeight: 380, objectFit: "cover" },
  imgPlaceholder: {
    width: "100%", height: 280, borderRadius: "var(--radius)",
    background: "linear-gradient(135deg, #1a1a2a, #0f1f1a)",
    display: "flex", alignItems: "center", justifyContent: "center", fontSize: "4rem",
  },
  tag: { fontFamily: "'DM Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.1em", color: "var(--emerald-lt)", marginBottom: "0.9rem", display: "block" },
  h1: { fontSize: "clamp(1.6rem, 3.5vw, 2.25rem)", fontWeight: 800, letterSpacing: "-0.03em", marginBottom: "0.6rem", lineHeight: 1.2 },
  location: { color: "var(--muted)", fontSize: "0.95rem", marginBottom: "1.25rem" },
  desc: { color: "var(--muted)", lineHeight: 1.75, fontSize: "0.9rem", marginBottom: "1.75rem" },
  metaGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.75rem", marginBottom: "1.75rem" },
  metaItem: { padding: "0.9rem", borderRadius: "10px", border: "1px solid var(--border)", background: "var(--bg2)" },
  metaLabel: { fontSize: "0.68rem", color: "var(--muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "0.3rem" },
  metaVal: { fontFamily: "'DM Mono', monospace", fontSize: "0.875rem", fontWeight: 500 },
  sidebar: { position: "sticky", top: 90, padding: "1.75rem", borderRadius: "var(--radius)", border: "1px solid var(--border)", background: "var(--bg2)" },
  priceVal: {
    fontFamily: "'DM Mono', monospace", fontSize: "1.75rem", fontWeight: 500,
    background: "linear-gradient(135deg, var(--emerald-lt), var(--gold-lt))",
    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
  },
  priceLabel: { color: "var(--muted)", fontSize: "0.75rem", marginBottom: "1.5rem" },
  label: { fontSize: "0.72rem", color: "var(--muted)", letterSpacing: "0.07em", textTransform: "uppercase", marginBottom: "0.4rem", display: "block" },
  dateInput: {
    width: "100%", padding: "0.7rem 0.9rem", borderRadius: "8px",
    border: "1px solid var(--border)", background: "var(--bg3)",
    color: "var(--text)", fontSize: "0.875rem", outline: "none", marginBottom: "0.75rem",
    boxSizing: "border-box",
  },
  costRow: {
    display: "flex", justifyContent: "space-between", padding: "0.9rem",
    borderRadius: "8px", border: "1px solid var(--border)",
    background: "var(--bg3)", marginBottom: "1rem", fontSize: "0.875rem",
  },
  bookBtn: {
    width: "100%", padding: "0.9rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 800, fontSize: "0.95rem", cursor: "pointer",
    marginTop: "0.75rem", transition: "opacity 0.2s",
    boxShadow: "0 0 24px rgba(5,150,105,0.3)",
  },
  disabledBtn: {
    width: "100%", padding: "0.9rem", borderRadius: "50px",
    border: "1px solid var(--border)", background: "var(--bg3)",
    color: "var(--muted)", fontWeight: 700, fontSize: "0.95rem",
    cursor: "not-allowed", marginTop: "0.75rem",
  },
  ownerTag: { marginTop: "1rem", fontSize: "0.72rem", color: "var(--muted)", fontFamily: "'DM Mono', monospace", padding: "0.6rem 0.9rem", borderRadius: "8px", border: "1px solid var(--border)", background: "var(--bg3)" },
  loading: { textAlign: "center", color: "var(--muted)", padding: "6rem" },
};

// Minimum date = tomorrow
const minDate = () => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().split("T")[0];
};

export default function RoomDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { contract, account, connect, isConnected, getReadOnlyContract } = useWeb3();

  const [room,     setRoom]     = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [checkIn,  setCheckIn]  = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [booking,  setBooking]  = useState(false);
  const [cost,     setCost]     = useState(null);

  const load = useCallback(async () => {
    try {
      const c = contract || getReadOnlyContract();
      if (!c) return;
      const r = await c.rooms(id);
      if (!r.exists) { navigate("/rooms"); return; }
      setRoom(r);
    } catch { navigate("/rooms"); }
    finally { setLoading(false); }
  }, [id, contract, getReadOnlyContract, navigate]);

  useEffect(() => { load(); }, [load]);

  // Recalculate cost whenever dates change
  useEffect(() => {
    if (!checkIn || !checkOut || !room) { setCost(null); return; }
    const nights = nightsBetween(checkIn, checkOut);
    if (nights <= 0) { setCost(null); return; }
    setCost(BigInt(nights) * room.pricePerNight);
  }, [checkIn, checkOut, room]);

  const handleBook = async () => {
    if (!isConnected) { connect(); return; }
    if (!contract || !cost) return;
    const ci = toUnix(checkIn);
    const co = toUnix(checkOut);
    if (ci <= Math.floor(Date.now() / 1000)) { toast.error("Check-in must be in the future."); return; }
    if (co <= ci) { toast.error("Check-out must be after check-in."); return; }

    setBooking(true);
    const tid = toast.loading("Confirm transaction in MetaMask…");
    try {
      const tx = await contract.bookRoom(id, ci, co, { value: cost });
      toast.loading("Waiting for confirmation…", { id: tid });
      await tx.wait();
      toast.success("🏨 Room booked! Check My Bookings.", { id: tid, duration: 5000 });
      await load();
    } catch (err) {
      toast.error(parseTxError(err), { id: tid });
    } finally {
      setBooking(false);
    }
  };

  if (loading) return <div style={s.loading}>Loading room…</div>;
  if (!room)   return null;

  const typeIdx  = Number(room.roomType);
  const color    = ROOM_TYPE_COLORS[typeIdx];
  const nights   = nightsBetween(checkIn, checkOut);
  const isOwner  = account && account.toLowerCase() === room.owner.toLowerCase();
  const canBook  = room.available && !isOwner && nights > 0 && cost;

  return (
    <div style={s.page}>
      <span style={s.back} onClick={() => navigate("/rooms")}>← Back to Rooms</span>
      <div style={s.layout}>
        {/* Left */}
        <div>
          {room.imageURI ? (
            <img src={room.imageURI} alt={room.name} style={s.img} />
          ) : (
            <div style={s.imgPlaceholder}>{roomTypeIcon(room.roomType)}</div>
          )}
          <div style={{ marginTop: "2rem" }}>
            <span style={s.tag}>ROOM #{room.id.toString()} · {roomTypeLabel(room.roomType).toUpperCase()}</span>
            <h1 style={s.h1}>{room.name}</h1>
            <div style={s.location}>📍 {room.location}</div>
            <p style={s.desc}>{room.description}</p>
            <div style={s.metaGrid}>
              {[
                { label: "Room Type",   val: `${roomTypeIcon(room.roomType)} ${roomTypeLabel(room.roomType)}` },
                { label: "Max Guests",  val: `👥 ${room.maxGuests.toString()}` },
                { label: "Price/Night", val: formatEth(room.pricePerNight) },
                { label: "Status",      val: room.available ? "✅ Available" : "❌ Unavailable" },
              ].map(({ label, val }) => (
                <div key={label} style={s.metaItem}>
                  <div style={s.metaLabel}>{label}</div>
                  <div style={s.metaVal}>{val}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div style={s.sidebar}>
          <div style={s.priceVal}>{formatEth(room.pricePerNight)}</div>
          <div style={s.priceLabel}>per night · paid in ETH</div>

          <label style={s.label}>Check-in</label>
          <input type="date" style={s.dateInput} min={minDate()} value={checkIn}
            onChange={e => setCheckIn(e.target.value)}
            onFocus={e => { e.target.style.borderColor = "var(--emerald)"; }}
            onBlur={e =>  { e.target.style.borderColor = "var(--border)"; }}
          />

          <label style={s.label}>Check-out</label>
          <input type="date" style={s.dateInput} min={checkIn || minDate()} value={checkOut}
            onChange={e => setCheckOut(e.target.value)}
            onFocus={e => { e.target.style.borderColor = "var(--emerald)"; }}
            onBlur={e =>  { e.target.style.borderColor = "var(--border)"; }}
          />

          {nights > 0 && cost && (
            <div style={s.costRow}>
              <span style={{ color: "var(--muted)" }}>{nights} night{nights > 1 ? "s" : ""}</span>
              <span style={{ fontFamily: "'DM Mono', monospace", color: "var(--emerald-lt)" }}>
                {formatEth(cost)}
              </span>
            </div>
          )}

          {!room.available ? (
            <button style={s.disabledBtn} disabled>Room Unavailable</button>
          ) : isOwner ? (
            <button style={s.disabledBtn} disabled>Your Own Room</button>
          ) : !isConnected ? (
            <button style={s.bookBtn} onClick={() => connect()}>Connect Wallet to Book</button>
          ) : (
            <button
              style={{ ...s.bookBtn, opacity: booking || !canBook ? 0.65 : 1 }}
              onClick={handleBook} disabled={booking || !canBook}
              onMouseEnter={e => { if (!booking && canBook) e.target.style.opacity = "0.82"; }}
              onMouseLeave={e => { e.target.style.opacity = booking || !canBook ? "0.65" : "1"; }}
            >
              {booking ? "Processing…" : nights > 0 ? `Book ${nights} Night${nights > 1 ? "s" : ""} →` : "Select Dates →"}
            </button>
          )}

          <div style={s.ownerTag}>Host: {shortAddr(room.owner)}</div>
          <div style={{ marginTop: "0.75rem", fontSize: "0.72rem", color: "var(--muted)", lineHeight: 1.6 }}>
            ℹ️ Full refund &gt;48 h before check-in · 50% refund within 48 h
          </div>
        </div>
      </div>
    </div>
  );
}
