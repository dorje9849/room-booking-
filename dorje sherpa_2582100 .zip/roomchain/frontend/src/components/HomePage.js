import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useWeb3 } from "../hooks/useWeb3";

const s = {
  hero: {
    minHeight: "88vh", display: "flex", flexDirection: "column",
    alignItems: "center", justifyContent: "center",
    textAlign: "center", padding: "4rem 2rem", position: "relative", overflow: "hidden",
  },
  glow1: {
    position: "absolute", width: 500, height: 500, borderRadius: "50%",
    background: "radial-gradient(circle, rgba(5,150,105,0.15) 0%, transparent 70%)",
    top: "-80px", left: "50%", transform: "translateX(-50%)", pointerEvents: "none",
  },
  glow2: {
    position: "absolute", width: 350, height: 350, borderRadius: "50%",
    background: "radial-gradient(circle, rgba(217,119,6,0.1) 0%, transparent 70%)",
    bottom: "60px", right: "8%", pointerEvents: "none",
  },
  eyebrow: {
    fontFamily: "'DM Mono', monospace", fontSize: "0.7rem", letterSpacing: "0.2em",
    color: "var(--emerald-lt)", textTransform: "uppercase", marginBottom: "1.5rem",
    padding: "0.35rem 1rem", border: "1px solid rgba(52,211,153,0.3)", borderRadius: "50px",
    background: "rgba(5,150,105,0.08)", display: "inline-block",
  },
  h1: {
    fontSize: "clamp(2.8rem, 7vw, 6rem)", fontWeight: 800,
    lineHeight: 0.95, letterSpacing: "-0.04em", marginBottom: "1.5rem",
  },
  grad: {
    background: "linear-gradient(135deg, #fff 20%, var(--emerald-lt) 55%, var(--gold-lt))",
    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
  },
  sub: {
    fontSize: "clamp(0.95rem, 1.8vw, 1.15rem)", color: "var(--muted)",
    maxWidth: 520, lineHeight: 1.75, marginBottom: "2.5rem",
  },
  ctaRow: { display: "flex", gap: "1rem", flexWrap: "wrap", justifyContent: "center" },
  cta: {
    padding: "0.9rem 2.25rem", borderRadius: "50px", border: "none",
    background: "linear-gradient(135deg, var(--emerald), var(--gold))",
    color: "#fff", fontWeight: 700, fontSize: "0.95rem", cursor: "pointer",
    transition: "transform 0.2s, box-shadow 0.2s",
    boxShadow: "0 0 36px rgba(5,150,105,0.4)",
  },
  ctaGhost: {
    padding: "0.9rem 2.25rem", borderRadius: "50px",
    border: "1px solid var(--border)", background: "transparent",
    color: "var(--text)", fontWeight: 700, fontSize: "0.95rem", cursor: "pointer",
    transition: "border-color 0.2s",
  },
  stats: {
    display: "flex", gap: "2rem", justifyContent: "center",
    flexWrap: "wrap", padding: "3rem 2rem",
    borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)",
    background: "var(--bg2)",
  },
  statCard: { textAlign: "center", padding: "1rem 2.5rem" },
  statVal: { fontFamily: "'DM Mono', monospace", fontSize: "2.2rem", fontWeight: 500, color: "var(--emerald-lt)" },
  statLabel: { color: "var(--muted)", fontSize: "0.75rem", marginTop: "0.4rem", letterSpacing: "0.08em" },
  features: {
    display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
    gap: "1.25rem", padding: "4rem 3rem", maxWidth: 1100, margin: "0 auto",
  },
  card: {
    padding: "1.75rem", borderRadius: "var(--radius)", border: "1px solid var(--border)",
    background: "var(--bg2)", transition: "border-color 0.3s, transform 0.2s",
  },
  cardIcon: { fontSize: "1.8rem", marginBottom: "0.9rem" },
  cardTitle: { fontWeight: 700, fontSize: "1rem", marginBottom: "0.6rem" },
  cardText: { color: "var(--muted)", lineHeight: 1.65, fontSize: "0.875rem" },
};

const FEATURES = [
  { icon: "🏨", title: "List Your Room", text: "Any property owner can list rooms with pricing, photos, and availability. No approval needed — just deploy and go." },
  { icon: "🔒", title: "Tamper-Proof Bookings", text: "Every reservation is written immutably to Ethereum. No overbooking, no fake listings, no disputes." },
  { icon: "💸", title: "Smart Refunds", text: "Full refund >48 h before check-in. 50% refund within 48 h. Enforced automatically — no waiting, no chasing." },
  { icon: "📅", title: "Overlap Protection", text: "The contract checks for date conflicts on-chain. Two guests cannot book the same room for overlapping nights." },
  { icon: "🌐", title: "No Middlemen", text: "Room owners receive 97% of every booking directly to their wallet. No platform extraction, no hidden fees." },
  { icon: "🛡️", title: "ReentrancyGuard", text: "All ETH transfers are protected by OpenZeppelin's ReentrancyGuard — the gold standard against exploit attacks." },
];

export default function HomePage() {
  const { getReadOnlyContract } = useWeb3();
  const [stats, setStats] = useState({ rooms: 0, bookings: 0 });

  useEffect(() => {
    (async () => {
      try {
        const c = getReadOnlyContract();
        if (!c) return;
        const [r, b] = await Promise.all([c.totalRooms(), c.totalBookings()]);
        setStats({ rooms: Number(r), bookings: Number(b) });
      } catch {}
    })();
  }, [getReadOnlyContract]);

  return (
    <div>
      <section style={s.hero}>
        <div style={s.glow1} /><div style={s.glow2} />
        <div style={s.eyebrow}>Ethereum · Trustless · Transparent</div>
        <h1 style={s.h1}><span style={s.grad}>Book rooms.<br />Own the record.</span></h1>
        <p style={s.sub}>
          RoomChain is a fully decentralised room booking platform.
          Every reservation is a blockchain transaction — immutable, fraud-proof, and instant.
        </p>
        <div style={s.ctaRow}>
          <Link to="/rooms">
            <button style={s.cta}
              onMouseEnter={e => { e.target.style.transform = "scale(1.04)"; e.target.style.boxShadow = "0 0 56px rgba(5,150,105,0.55)"; }}
              onMouseLeave={e => { e.target.style.transform = "scale(1)";    e.target.style.boxShadow = "0 0 36px rgba(5,150,105,0.4)"; }}
            >Browse Rooms →</button>
          </Link>
          <Link to="/list">
            <button style={s.ctaGhost}
              onMouseEnter={e => { e.target.style.borderColor = "var(--emerald-lt)"; }}
              onMouseLeave={e => { e.target.style.borderColor = "var(--border)"; }}
            >List a Room</button>
          </Link>
        </div>
      </section>

      <div style={s.stats}>
        {[
          { val: stats.rooms,    label: "ROOMS LISTED"     },
          { val: stats.bookings, label: "BOOKINGS ON-CHAIN" },
          { val: "3%",           label: "PLATFORM FEE"     },
          { val: "100%",         label: "DECENTRALISED"    },
        ].map(({ val, label }) => (
          <div key={label} style={s.statCard}>
            <div style={s.statVal}>{val}</div>
            <div style={s.statLabel}>{label}</div>
          </div>
        ))}
      </div>

      <div style={s.features}>
        {FEATURES.map(f => (
          <div key={f.title} style={s.card}
            onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--emerald)"; e.currentTarget.style.transform = "translateY(-4px)"; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border)";  e.currentTarget.style.transform = "translateY(0)"; }}
          >
            <div style={s.cardIcon}>{f.icon}</div>
            <div style={s.cardTitle}>{f.title}</div>
            <div style={s.cardText}>{f.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
