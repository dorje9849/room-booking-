// src/hooks/useWeb3.js
import { useState, useEffect, useCallback, createContext, useContext } from "react";
import { ethers } from "ethers";
import toast from "react-hot-toast";
import contractArtifact from "../contracts/RoomChain.json";

const Web3Context = createContext(null);
const TARGET_CHAIN = 31337;

export function Web3Provider({ children }) {
  const [provider,   setProvider]   = useState(null);
  const [signer,     setSigner]     = useState(null);
  const [contract,   setContract]   = useState(null);
  const [account,    setAccount]    = useState(null);
  const [chainId,    setChainId]    = useState(null);
  const [connecting, setConnecting] = useState(false);

  const initContract = useCallback((sp) => {
    const c = new ethers.Contract(contractArtifact.address, contractArtifact.abi, sp);
    setContract(c);
    return c;
  }, []);

  useEffect(() => {
    if (window.ethereum?.selectedAddress) connect(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!window.ethereum) return;
    const onAccounts = (accs) => { if (accs.length === 0) disconnect(); else setAccount(accs[0]); };
    const onChain    = () => window.location.reload();
    window.ethereum.on("accountsChanged", onAccounts);
    window.ethereum.on("chainChanged",    onChain);
    return () => {
      window.ethereum.removeListener("accountsChanged", onAccounts);
      window.ethereum.removeListener("chainChanged",    onChain);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const connect = async (silent = false) => {
    if (!window.ethereum) { if (!silent) toast.error("MetaMask not found."); return; }
    setConnecting(true);
    try {
      const bp  = new ethers.BrowserProvider(window.ethereum);
      await bp.send("eth_requestAccounts", []);
      const s   = await bp.getSigner();
      const net = await bp.getNetwork();
      setProvider(bp);
      setSigner(s);
      setAccount(await s.getAddress());
      setChainId(Number(net.chainId));
      initContract(s);
      if (Number(net.chainId) !== TARGET_CHAIN && !silent)
        toast("⚠️ Switch to Hardhat network (chainId 31337)", { duration: 5000 });
    } catch (err) {
      if (!silent) toast.error("Wallet connection failed");
      console.error(err);
    } finally {
      setConnecting(false);
    }
  };

  const disconnect = () => {
    setProvider(null); setSigner(null); setContract(null);
    setAccount(null);  setChainId(null);
  };

  const getReadOnlyContract = useCallback(() => {
    if (contract) return contract;
    if (!contractArtifact.address) return null;
    const rpc = new ethers.JsonRpcProvider("http://127.0.0.1:8545");
    return new ethers.Contract(contractArtifact.address, contractArtifact.abi, rpc);
  }, [contract]);

  return (
    <Web3Context.Provider value={{
      provider, signer, contract, account, chainId, connecting,
      connect, disconnect, getReadOnlyContract,
      isConnected:    !!account,
      isCorrectChain: chainId === TARGET_CHAIN,
    }}>
      {children}
    </Web3Context.Provider>
  );
}

export const useWeb3 = () => {
  const ctx = useContext(Web3Context);
  if (!ctx) throw new Error("useWeb3 must be inside Web3Provider");
  return ctx;
};
