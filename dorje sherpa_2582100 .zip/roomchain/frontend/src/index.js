import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import App from "./App";
import "./styles/global.css";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "#12121e",
            color: "#e2e8f0",
            border: "1px solid #252540",
            borderRadius: "12px",
            fontFamily: "'DM Sans', sans-serif",
          },
          success: { iconTheme: { primary: "#10b981", secondary: "#e2e8f0" } },
          error:   { iconTheme: { primary: "#f43f5e", secondary: "#e2e8f0" } },
        }}
      />
    </BrowserRouter>
  </React.StrictMode>
);
