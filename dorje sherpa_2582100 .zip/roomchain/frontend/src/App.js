// src/App.js
import React from "react";
import { Routes, Route } from "react-router-dom";
import { Web3Provider } from "./hooks/useWeb3";
import Navbar      from "./components/Navbar";
import HomePage    from "./components/HomePage";
import RoomsPage   from "./components/RoomsPage";
import RoomDetail  from "./components/RoomDetail";
import MyBookings  from "./components/MyBookings";
import ListRoom    from "./components/ListRoom";
import HostDash    from "./components/HostDash";

const footerStyle = {
  padding: "2rem",
  textAlign: "center",
  borderTop: "1px solid var(--border)",
  color: "var(--muted)",
  fontFamily: "'DM Mono', monospace",
  fontSize: "0.75rem",
};

export default function App() {
  return (
    <Web3Provider>
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        <Navbar />
        <main style={{ flex: 1 }}>
          <Routes>
            <Route path="/"             element={<HomePage />}   />
            <Route path="/rooms"        element={<RoomsPage />}  />
            <Route path="/rooms/:id"    element={<RoomDetail />} />
            <Route path="/my-bookings"  element={<MyBookings />} />
            <Route path="/list-room"    element={<ListRoom />}   />
            <Route path="/host-dash"    element={<HostDash />}   />
          </Routes>
        </main>
        <footer style={footerStyle}>
          RoomChain · Built on Ethereum · CN6035 DApp Project
        </footer>
      </div>
    </Web3Provider>
  );
}
